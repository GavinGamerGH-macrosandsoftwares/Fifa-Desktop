import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/home/runner/workspace/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a949a96c"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/@fs/home/runner/workspace/node_modules/.vite/deps/react.js?v=a949a96c"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import __vite__cjsImport2_reactDom_client from "/@fs/home/runner/workspace/node_modules/.vite/deps/react-dom_client.js?v=a949a96c"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import App from "/src/App.tsx?v=LUojGmYnIqBiawN7HT1O0";
import "/src/index.css?v=LUojGmYnIqBiawN7HT1O0";
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found!");
}
const root = createRoot(rootElement);
root.render(
  /* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/home/runner/workspace/client/src/main.tsx?v=LUojGmYnIqBiawN7HT1O0",
    lineNumber: 16,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/home/runner/workspace/client/src/main.tsx?v=LUojGmYnIqBiawN7HT1O0",
    lineNumber: 15,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUk7QUFmSixTQUFTQSxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLFNBQVM7QUFDaEIsT0FBTztBQUVQLE1BQU1DLGNBQWNDLFNBQVNDLGVBQWUsTUFBTTtBQUVsRCxJQUFJLENBQUNGLGFBQWE7QUFDaEIsUUFBTSxJQUFJRyxNQUFNLHlCQUF5QjtBQUMzQztBQUVBLE1BQU1DLE9BQU9OLFdBQVdFLFdBQVc7QUFFbkNJLEtBQUtDO0FBQUFBLEVBQ0gsdUJBQUMsY0FDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUNGIiwibmFtZXMiOlsiU3RyaWN0TW9kZSIsImNyZWF0ZVJvb3QiLCJBcHAiLCJyb290RWxlbWVudCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJFcnJvciIsInJvb3QiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcFwiO1xuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcblxuY29uc3Qgcm9vdEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIik7XG5cbmlmICghcm9vdEVsZW1lbnQpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiUm9vdCBlbGVtZW50IG5vdCBmb3VuZCFcIik7XG59XG5cbmNvbnN0IHJvb3QgPSBjcmVhdGVSb290KHJvb3RFbGVtZW50KTtcblxucm9vdC5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9TdHJpY3RNb2RlPlxuKTtcbiJdLCJmaWxlIjoiL2hvbWUvcnVubmVyL3dvcmtzcGFjZS9jbGllbnQvc3JjL21haW4udHN4In0=